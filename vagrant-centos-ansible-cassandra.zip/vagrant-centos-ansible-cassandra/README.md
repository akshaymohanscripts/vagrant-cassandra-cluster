
Step1: 
Clone the project: ```git clone https://github.com/matthewlboyd/vagrant-centos-ansible-cassandra.git```

Step 2:
cd vagrant-centos-ansible-cassandrax

Step3:
Run ```vagrant up```



